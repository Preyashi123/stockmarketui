import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managesector',
  templateUrl: './managesector.component.html',
  styleUrls: ['./managesector.component.css']
})
export class ManagesectorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
