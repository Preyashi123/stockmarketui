import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rendermap',
  templateUrl: './rendermap.component.html',
  styleUrls: ['./rendermap.component.css']
})
export class RendermapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
