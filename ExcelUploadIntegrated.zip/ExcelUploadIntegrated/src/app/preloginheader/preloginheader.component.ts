import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preloginheader',
  templateUrl: './preloginheader.component.html',
  styleUrls: ['./preloginheader.component.css']
})
export class PreloginheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
